#ifndef __KEY_H_
#define __KEY_H_
#include"sys.h"
#define KEY_GPIO_PIN GPIO_Pin_13
#define KEY_GPIO_PORT GPIOA
#define KEY_GPIO_CLK RCC_APB2Periph_GPIOA

extern u8 flag;

/*SW1:PA2  SW2:PA13  SW3:PA6   SW4:PA7*/

void KEY_GPIO_Config(void);  //key��ʼ��
void LED_Change(void);
void KEY_Scan(void);



#endif

